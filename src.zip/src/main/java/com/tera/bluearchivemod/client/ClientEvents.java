package com.tera.bluearchivemod.client;

import com.tera.bluearchivemod.item.MyItem;
import com.tera.bluearchivemod.item.MyItemRenderer;
import com.tera.bluearchivemod.ModItems;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = "bluearchivemod", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientEvents {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModItems.MY_ITEM.get(), MyItemRenderer::new);
    }
}