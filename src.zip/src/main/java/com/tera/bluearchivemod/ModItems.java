package com.tera.bluearchivemod;

import com.tera.bluearchivemod.item.MyItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import javax.xml.crypto.XMLCryptoContext;

/**
 * MOD内のアイテムをまとめて登録するクラス
 */
public class ModItems {

    // アイテムを登録するDeferredRegister
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(
            ForgeRegistries.ITEMS, "bluearchivemod");

    public static XMLCryptoContext MY_ITEM;
}