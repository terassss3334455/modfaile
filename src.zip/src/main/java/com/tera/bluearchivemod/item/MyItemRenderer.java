package com.tera.bluearchivemod.item;

import software.bernie.geckolib.renderer.GeoItemRenderer;
import com.tera.bluearchivemod.model.MyItemModel;

public class MyItemRenderer extends GeoItemRenderer<MyItem> {
    public MyItemRenderer() {
        super(new MyItemModel());
    }
}