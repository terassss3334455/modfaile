package com.tera.bluearchivemod.model;

import com.tera.bluearchivemod.item.MyItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class MyItemModel extends GeoModel<MyItem> {

    @Override
    public ResourceLocation getModelResource(MyItem object) {
        return new ResourceLocation("bluearchivemod", "geo/my_item.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(MyItem object) {
        return new ResourceLocation("bluearchivemod", "textures/item/my_item.png");
    }

    @Override
    public ResourceLocation getAnimationResource(MyItem object) {
        // 空のアニメーションでもOK
        return new ResourceLocation("bluearchivemod", "animations/my_item_animation.json");
    }
}